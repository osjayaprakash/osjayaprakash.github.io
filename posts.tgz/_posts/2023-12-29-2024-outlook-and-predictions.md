---
layout: post
title: Outlook and Predictions for 2024
permalink: /2023-12-29-2024-Outlook-and-predictions.html
categories: misc
---

> The last two years (2022-23) has been volatile and nosiy in terms of Economy and COVID. The interest rates were dropped (0% in 2021) due-to COVID pandemic, led to higher inflation, then Fed increased rates to tame the inflation (6% in 2023).
Quick changes in the monetary policies were unexpected. The vast majority of population (including big companies) doesn't seem to know how to react to these changes and reacted poorly. 

When the interest rates dropped:
* Average consumers went on spending spree.
* Housing prices shored. This led to heavy competition for even not-so-good houses.
* Stock prices went up (RIVN was valued more than 60B without releasing a single car).
* Used car was valued more than new car because new cars take time (CARVANA stocks went up).
* Sudden market demand for consumer products and subsequently shortage of supplies. 
* Top companies thought that they are missing out huge oppurtunity in the sudden increase in consumer demand.
  * Companies start hiring employees in large scale with lot of benefits.
  * Started investing in new bold bets.
  * Hiring included lavish option of working remotely (Facebook and Twitter offered to work remotely permanently)

When the interest rates increased:
 * Cosumer mood has changed. They started spending less.
 * House prices dropped significantly.
 * Most of top stocks were down by ~40-50% from their peek.
 * Valuation of companies are reduced (Some companies went of their way to reduced their valuation by themselves - Instacart for example).
 * Companies (such as TESLA) started slashing prices, after cosumer demand has reduced due to limited borrowing.
 * Top companies realized and pressured to reduced spending and cutting costs.
   * Reduced hiring. Stared firing/mass laying off employees.
   * Reduced the investments wherever possible.
   * Enforced employees to come to office. The remote jobs are rare in big companies (with exceptions to startups)

> What could have been changed in the past two years? How do I handle such events in future?

### Summary of predictions
* Higher interest rates is here to stay for many more years. This may higher than what people used from 2008. -- Vanguard
* Bonds will perform better in the next decade (4.8 to 5.8%).
* US equities may not perform well (4.2 to 6.5%) in the next decade.
  * Valuations are likely to suffer due to squeezed profit margins, high cost of borrowing, etc.
  * Non-US market likely perform better than US, due to USD strength (What is this?)  
  * Non-US developed markets expected to 7 to 9%
  * Emerging markets to grow 6.6 to 8.6%
* Value stocks are better than Growth stocks.
* Fed will likely start cutting the interest rates in mid-2024.
  * ALSO, there is a possiblity that US economoy will hit formal recession (will be formally annouced). 

References: 
 * <https://investor.vanguard.com/investor-resources-education/news/vanguard-economic-market-outlook-2024-global-summary>
 * <https://www.goldmansachs.com/intelligence/pages/2024-us-equity-outlook-all-you-had-to-do-was-stay.html>
 * <https://www.schwab.com/learn/story/outlook-overview>
